
class User:
    def __init__(self, username):
        self.username = username
        self.dir_name = f"{self.username}_scraped"
